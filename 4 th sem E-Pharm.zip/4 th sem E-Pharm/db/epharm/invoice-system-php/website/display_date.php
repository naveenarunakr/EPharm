<?php
$a=$_POST["file_name_des"];

$host = "localhost";
$username = "root";
$password = "";
$dbname = "users";


$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO file_des (file_name)
VALUES ('$a')";

if ($conn->query($sql) === TRUE) {
  
  echo" <script> window.alert('Data has been securly stored') </script> ";
//   header('Location: http://localhost/poovithaproject/login.html');
  echo"data stored";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>