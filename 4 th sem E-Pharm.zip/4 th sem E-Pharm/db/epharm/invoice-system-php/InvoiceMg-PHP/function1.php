<?php


include_once("includes/config.php");
function popProductsList() {

// Connect to the database
$mysqli = new mysqli(DATABASE_HOST, DATABASE_USER, DATABASE_PASS, DATABASE_NAME);

// output any connection error
if ($mysqli->connect_error) {
    die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
}

// the query
$query = "SELECT * FROM products ORDER BY product_name ASC";

// mysqli select query
$results = $mysqli->query($query);

if($results) {
    echo '<select class="form-control item-select">';
    while($row = $results->fetch_assoc()) {

        print '<option value="'.$row['product_price'].'">'.$row["product_name"].' - '.$row["product_desc"].'</option>';
    }
    echo '</select>';

} else {

    echo "<p>There are no products, please add a product.</p>";

}

// Frees the memory associated with a result
$results->free();

// close connection 
$mysqli->close();

}

?>