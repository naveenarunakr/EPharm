<?php 
$id=$_POST['id'];
$name=$_POST['Medicion_Name'];
$Quantity=$_POST['Quantity'];
$manu_date=$_POST['Manu_Date'];
$ex_date=$_POST['Ex_date'];
$shop_name=$_POST['Shop_name'];
$price=$_POST['price'];
$prescription=$_POST['prescription'];





$host = "localhost";
$username = "root";
$password = "";
$dbname = "mysite";


$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO search (id,name,quantity,manu_date,ex_date,shop_name,price,prescription)
VALUES ('$id','$name','$Quantity','$manu_date','$ex_date','$shop_name','$price','$prescription')";

if ($conn->query($sql) === TRUE) {
  
  echo" <script> window.alert('Data has been securly stored') </script> ";
  header('Location: addproduct.html');
 
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>